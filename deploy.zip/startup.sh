#!/bin/bash

# Install Playwright browsers
python -m playwright install chromium
python -m playwright install-deps chromium

# Start the application
gunicorn -w 4 -k uvicorn.workers.UvicornWorker main:app --bind 0.0.0.0:8000
